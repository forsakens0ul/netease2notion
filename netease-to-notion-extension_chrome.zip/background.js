// 监听安装事件
chrome.runtime.onInstalled.addListener(() => {
  console.log("NetEase to Notion extension installed");
});

// 监听来自扩展页面的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("收到消息:", message);

  if (message.action === "clearAuth") {
    // 清除存储的授权信息
    chrome.storage.local.remove(["notionToken", "neteaseUID"], () => {
      sendResponse({ success: true });
    });
    return true; // 保持消息通道开放以异步回复
  }

  // 处理从外部页面获取的令牌
  if (message.action === "setNotionToken" && message.token) {
    console.log("保存Notion令牌:", message.token.substring(0, 10) + "...");

    // 保存令牌到存储
    chrome.storage.local.set({ notionToken: message.token }, () => {
      // 通知popup页面令牌已保存
      try {
        chrome.runtime
          .sendMessage({
            action: "tokenSaved",
            token: message.token,
          })
          .catch((err) => console.error("发送消息失败:", err));
      } catch (err) {
        console.error("发送消息时出错:", err);
      }

      sendResponse({ success: true });
    });
    return true; // 保持消息通道开放以异步回复
  }
});

// 监听标签页更新，处理授权回调
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url && changeInfo.url.includes("success?access_token=")) {
    console.log("检测到授权回调URL:", changeInfo.url);

    try {
      // 从URL中提取访问令牌
      const urlObj = new URL(changeInfo.url);
      const accessToken = urlObj.searchParams.get("access_token");

      if (accessToken) {
        console.log("提取到访问令牌:", accessToken.substring(0, 10) + "...");

        // 保存令牌到存储
        chrome.storage.local.set({ notionToken: accessToken }, () => {
          console.log("令牌已保存到存储");

          // 通知popup页面令牌已保存
          try {
            chrome.runtime
              .sendMessage({
                action: "tokenSaved",
                token: accessToken,
              })
              .catch((err) => console.error("发送消息失败:", err));
          } catch (err) {
            console.error("发送消息时出错:", err);
          }

          // 关闭标签页
          try {
            chrome.tabs.remove(tabId);
          } catch (err) {
            console.error("关闭标签页时出错:", err);
          }
        });
      }
    } catch (error) {
      console.error("处理授权回调时出错:", error);
    }
  }
});
