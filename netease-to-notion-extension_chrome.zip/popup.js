// 存储Notion授权信息和用户UID
let notionToken = "";
let neteaseUID = "";

// API端点 - 使用公开部署的API
const API_BASE_URL = "https://netease-cloud-music-api-tau-one-92.vercel.app";
const NOTION_API_URL = "https://api.notion.com/v1";

// 调试模式
const DEBUG_MODE = true;

// 调试日志函数
function debugLog(...args) {
  if (DEBUG_MODE) {
    console.log("[DEBUG]", ...args);
  }
}

// 处理Notion OAuth token
function processNotionToken(token) {
  // 记录原始token格式
  debugLog("处理token:", token ? token.substring(0, 10) + "..." : "无效token");

  // 检查token格式
  if (!token) return null;

  // 确保token没有URL编码
  try {
    // 如果token是URL编码的，解码它
    if (token.includes("%")) {
      const decodedToken = decodeURIComponent(token);
      debugLog("已解码token:", decodedToken.substring(0, 10) + "...");
      token = decodedToken;
    }

    // 注意：不再移除Bearer前缀，因为Notion API需要它
    // 只移除可能的引号
    if (token.startsWith('"') && token.endsWith('"')) {
      token = token.substring(1, token.length - 1);
      debugLog("移除引号:", token.substring(0, 10) + "...");
    }
  } catch (e) {
    debugLog("处理token时出错:", e);
  }

  // 确保令牌有正确的Bearer前缀
  if (token && !token.startsWith("Bearer ") && !token.startsWith("bearer ")) {
    token = `Bearer ${token}`;
    debugLog("添加Bearer前缀:", token.substring(0, 20) + "...");
  }

  return token;
}

// 监听来自background.js的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  debugLog("收到消息:", message);

  // 处理保存的令牌
  if (message.action === "tokenSaved" && message.token) {
    debugLog("收到保存的令牌:", message.token.substring(0, 10) + "...");

    // 更新本地变量
    notionToken = message.token;

    // 显示授权结果
    showAuthResult(true, message.token);

    // 更新状态
    document.getElementById("status").textContent = "Notion 授权成功！";
    document.getElementById("sync-data").disabled = !(
      notionToken && neteaseUID
    );

    // 显示授权成功区域和下载CSV按钮
    document.getElementById("auth-success-section").style.display = "block";

    // 确认发送成功
    if (sendResponse) {
      sendResponse({ success: true });
    }
  }
});

// 从存储中加载数据
chrome.storage.local.get(["notionToken", "neteaseUID"], function (result) {
  if (result.notionToken) {
    notionToken = result.notionToken;
    document.getElementById("status").textContent = "Notion 已授权";
    document.getElementById("sync-data").disabled = false;
    debugLog(
      "从存储加载的Notion令牌:",
      result.notionToken.substring(0, 10) + "..."
    );

    // 显示授权成功区域和下载CSV按钮
    document.getElementById("auth-success-section").style.display = "block";
  } else {
    debugLog("未找到存储的Notion令牌");
  }

  if (result.neteaseUID) {
    neteaseUID = result.neteaseUID;
    document.getElementById("netease-uid").value = neteaseUID;
    debugLog("从存储加载的网易云UID:", neteaseUID);
  } else {
    debugLog("未找到存储的网易云UID");
  }

  // 检查同步按钮状态
  debugLog(
    "同步按钮状态检查 - Notion令牌:",
    !!notionToken,
    "网易云UID:",
    !!neteaseUID
  );
  document.getElementById("sync-data").disabled = !(notionToken && neteaseUID);
});

// 监听UID输入变化
document.getElementById("netease-uid").addEventListener("input", function () {
  neteaseUID = this.value.trim();

  // 保存到存储
  chrome.storage.local.set({ neteaseUID: neteaseUID });

  // 如果已授权且有UID，启用同步按钮
  document.getElementById("sync-data").disabled = !(notionToken && neteaseUID);
});

// Notion授权
document.getElementById("auth-notion").addEventListener("click", () => {
  document.getElementById("status").textContent = "正在准备授权...";

  const clientId = "208d872b-594c-80ec-a8ef-00372cbeec91"; // 请替换为你的Notion集成ClientID
  const clientSecret = "secret_aKx7qjg5U2d42SB4ZUEoOeNRpbvQ21IHLk6Vle1Ap1l"; // 请替换为你的Notion集成Secret
  const redirectUri =
    "https://v0-new-project-s6hp1wgs2wz.vercel.app/api/notion/callback";

  // 保存clientId和clientSecret到本地存储，以便后续使用
  chrome.storage.local.set({
    notionClientId: clientId,
    notionClientSecret: clientSecret,
    notionRedirectUri: redirectUri,
  });

  const notionAuthUrl =
    `https://api.notion.com/v1/oauth/authorize` +
    `?owner=user` +
    `&client_id=${clientId}` +
    `&redirect_uri=${encodeURIComponent(redirectUri)}` +
    `&response_type=code`;

  debugLog("尝试打开授权URL:", notionAuthUrl);
  document.getElementById("status").textContent = "正在打开授权页面...";

  // 监听授权结果的函数
  function checkForAuthResult(tabId, changeInfo, tab) {
    // 检查URL是否存在
    if (!changeInfo.url) return;

    // 提取URL中的参数
    try {
      const url = changeInfo.url;
      debugLog("检测到URL变化:", url);

      // 检查是否包含成功标记和临时授权码
      if (url.includes("success") && url.includes("code=")) {
        debugLog("检测到授权成功回调");

        // 从URL中提取临时授权码
        let authCode = "";
        try {
          const urlObj = new URL(url);
          authCode = urlObj.searchParams.get("code");
        } catch (e) {
          // 如果URL解析失败，尝试手动提取code
          const codeMatch = url.match(/code=([^&]+)/);
          if (codeMatch && codeMatch[1]) {
            authCode = codeMatch[1];
          }
        }

        debugLog(
          "提取的临时授权码:",
          authCode ? authCode.substring(0, 10) + "..." : "未找到"
        );

        if (authCode) {
          // 移除监听器
          chrome.tabs.onUpdated.removeListener(checkForAuthResult);

          // 关闭标签页
          chrome.tabs.remove(tabId);

          // 使用临时授权码交换访问令牌
          exchangeCodeForToken(authCode);
        }
      }
      // 如果URL包含access_token参数(旧版callback方式)
      else if (url.includes("success?access_token=")) {
        debugLog("检测到旧版授权成功回调(直接返回access_token)");

        // 从URL中提取访问令牌
        let accessToken = "";
        try {
          const urlObj = new URL(url);
          accessToken = urlObj.searchParams.get("access_token");
        } catch (e) {
          // 如果URL解析失败，尝试手动提取token
          const tokenMatch = url.match(/access_token=([^&]+)/);
          if (tokenMatch && tokenMatch[1]) {
            accessToken = tokenMatch[1];
          }
        }

        debugLog(
          "提取的访问令牌:",
          accessToken ? accessToken.substring(0, 10) + "..." : "未找到"
        );

        if (accessToken) {
          // 移除监听器
          chrome.tabs.onUpdated.removeListener(checkForAuthResult);

          // 关闭标签页
          chrome.tabs.remove(tabId);

          // 处理并保存令牌
          accessToken = processNotionToken(accessToken);
          notionToken = accessToken;
          chrome.storage.local.set({ notionToken: notionToken });

          // 显示授权结果
          showAuthResult(true, accessToken);

          // 更新状态
          document.getElementById("status").textContent = "Notion 授权成功！";
          document.getElementById("sync-data").disabled = !(
            notionToken && neteaseUID
          );
        }
      }
      // 检查是否包含错误标记
      else if (url.includes("error=")) {
        debugLog("检测到授权失败回调");

        // 移除监听器
        chrome.tabs.onUpdated.removeListener(checkForAuthResult);

        // 关闭标签页
        chrome.tabs.remove(tabId);

        // 显示授权失败
        showAuthResult(false);
      }
    } catch (error) {
      debugLog("处理授权回调时出错:", error);
    }
  }

  // 开始监听标签页更新
  chrome.tabs.onUpdated.addListener(checkForAuthResult);

  // 方法1: 尝试直接在新窗口打开
  window.open(notionAuthUrl, "_blank");

  // 方法2: 如果window.open不起作用，尝试创建一个链接并模拟点击
  setTimeout(() => {
    try {
      document.getElementById("status").textContent =
        "正在尝试备用方法打开授权页面...";
      const a = document.createElement("a");
      a.href = notionAuthUrl;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (error) {
      debugLog("备用方法打开授权页面失败:", error);
      document.getElementById("status").textContent =
        "打开授权页面失败，请查看控制台";
    }
  }, 1000);

  // 方法3: 如果上述方法都不起作用，尝试使用chrome.tabs.create
  setTimeout(() => {
    try {
      if (chrome && chrome.tabs && chrome.tabs.create) {
        document.getElementById("status").textContent =
          "正在尝试使用chrome.tabs打开授权页面...";
        chrome.tabs.create({ url: notionAuthUrl }, (tab) => {
          debugLog("已打开授权标签页:", tab ? tab.id : "未知");
        });
      }
    } catch (error) {
      debugLog("使用chrome.tabs打开授权页面失败:", error);
      document.getElementById("status").textContent =
        "所有方法均失败，请手动复制链接";

      // 显示链接供用户复制
      const linkContainer = document.createElement("div");
      linkContainer.style.marginTop = "10px";
      linkContainer.style.wordBreak = "break-all";
      linkContainer.innerHTML = `<small>请复制此链接并在浏览器中打开:<br><a href="${notionAuthUrl}" target="_blank">${notionAuthUrl}</a></small>`;
      document.body.appendChild(linkContainer);
    }
  }, 2000);
});

// 使用授权码交换访问令牌的函数
async function exchangeCodeForToken(code) {
  try {
    document.getElementById("status").textContent = "正在获取Notion访问令牌...";
    debugLog("准备使用授权码交换访问令牌:", code);

    // 从存储中获取客户端ID和密钥
    const credentials = await new Promise((resolve) => {
      chrome.storage.local.get(
        ["notionClientId", "notionClientSecret", "notionRedirectUri"],
        (result) => {
          resolve(result);
        }
      );
    });

    if (!credentials.notionClientId || !credentials.notionClientSecret) {
      throw new Error("找不到Notion集成凭据");
    }

    const clientId = credentials.notionClientId;
    const clientSecret = credentials.notionClientSecret;
    const redirectUri = credentials.notionRedirectUri;

    // 方法1: 使用代理服务器来避免CORS问题
    let tokenData = null;
    let error = null;

    try {
      // 使用代理服务器
      const proxyUrl =
        "https://v0-new-project-s6hp1wgs2wz.vercel.app/api/notion/exchange";

      // 发送请求到代理服务器
      const response = await fetch(proxyUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          code: code,
          redirect_uri: redirectUri,
          client_id: clientId,
          client_secret: clientSecret,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`代理交换令牌失败: ${response.status} - ${errorText}`);
      }

      tokenData = await response.json();
      debugLog("通过代理获取到访问令牌");
    } catch (proxyError) {
      error = proxyError;
      debugLog("代理交换访问令牌时出错:", proxyError);
      document.getElementById("status").textContent = "正在尝试备用方法...";

      // 方法2: 使用Notion的预设回调
      // 如果我们已经有了一个access_token，可能是通过其他方式获取的
      if (notionToken && notionToken.startsWith("ntn_")) {
        debugLog("使用已存在的访问令牌");
        tokenData = { access_token: notionToken };
      } else {
        throw proxyError; // 重新抛出错误，因为我们没有备用令牌
      }
    }

    // 从响应中提取访问令牌
    if (tokenData && tokenData.access_token) {
      const accessToken = tokenData.access_token;

      // 处理并保存令牌
      notionToken = processNotionToken(accessToken);
      const storageData = { notionToken: notionToken };

      // 如果有其他数据，也保存
      if (tokenData.workspace_id)
        storageData.notionWorkspaceId = tokenData.workspace_id;
      if (tokenData.bot_id) storageData.notionBotId = tokenData.bot_id;

      chrome.storage.local.set(storageData);

      // 显示授权结果
      showAuthResult(true, accessToken);

      // 更新状态
      document.getElementById("status").textContent = "Notion 授权成功！";
      document.getElementById("sync-data").disabled = !(
        notionToken && neteaseUID
      );
    } else {
      throw new Error("响应中没有访问令牌");
    }
  } catch (error) {
    debugLog("交换访问令牌时出错:", error);
    document.getElementById(
      "status"
    ).textContent = `授权失败: ${error.message}`;
    showAuthResult(false);
  }
}

// 显示授权结果
function showAuthResult(success, token = "") {
  const authResult = document.getElementById("auth-result");
  const authTitle = document.getElementById("auth-title");
  const tokenDisplay = document.getElementById("token-display");
  const authMessage = document.getElementById("auth-message");
  const copyBtn = document.getElementById("copy-btn");

  authResult.style.display = "block";

  if (success) {
    authTitle.textContent = "授权成功";
    authTitle.className = "success";
    tokenDisplay.textContent = token;
    authMessage.textContent =
      '请复制上面的令牌并保存，以备不时之需。系统已自动保存令牌，您可以直接点击"开始同步"按钮。';

    // 设置复制按钮功能
    copyBtn.style.display = "block";
    copyBtn.onclick = () => {
      navigator.clipboard
        .writeText(token)
        .then(() => {
          copyBtn.textContent = "已复制!";
          setTimeout(() => {
            copyBtn.textContent = "复制令牌";
          }, 2000);
        })
        .catch((err) => {
          debugLog("复制失败:", err);
          copyBtn.textContent = "复制失败";
        });
    };
  } else {
    authTitle.textContent = "授权失败";
    authTitle.className = "error";
    tokenDisplay.style.display = "none";
    copyBtn.style.display = "none";
    authMessage.textContent =
      "Notion授权失败，请重试。如果问题持续存在，请检查您的Notion集成设置。";
  }
}

// 初始化复制按钮事件
document.getElementById("copy-btn").addEventListener("click", function () {
  const tokenDisplay = document.getElementById("token-display");
  navigator.clipboard
    .writeText(tokenDisplay.textContent)
    .then(() => {
      this.textContent = "已复制!";
      setTimeout(() => {
        this.textContent = "复制令牌";
      }, 2000);
    })
    .catch((err) => {
      debugLog("复制失败:", err);
      this.textContent = "复制失败";
    });
});

// 同步数据
document.getElementById("sync-data").addEventListener("click", async () => {
  try {
    // 获取输入框中的网易云UID
    const inputUID = document.getElementById("netease-uid").value.trim();
    if (inputUID) {
      neteaseUID = inputUID;
      chrome.storage.local.set({ neteaseUID: neteaseUID });
    }

    if (!neteaseUID) {
      document.getElementById("status").textContent = "请先输入网易云音乐UID";
      return;
    }

    // 检查是否有令牌，如果没有则尝试从存储中获取
    if (!notionToken) {
      await new Promise((resolve) => {
        chrome.storage.local.get(["notionToken"], function (result) {
          if (result.notionToken) {
            notionToken = result.notionToken;
            // 处理可能存储的token
            notionToken = processNotionToken(notionToken);
            debugLog(
              "从存储中获取到令牌:",
              notionToken.substring(0, 10) + "..."
            );
          }
          resolve();
        });
      });
    }

    // 如果仍然没有令牌，提示用户授权
    if (!notionToken) {
      debugLog("未找到有效令牌，需要授权");
      document.getElementById("status").textContent = "请先授权Notion";
      document.getElementById("sync-data").disabled = true;
      return;
    }

    document.getElementById("status").textContent = "同步中，请稍候...";
    document.getElementById("sync-data").disabled = true;

    // 定义授权头变量，确保在整个函数中可用
    let authHeader = `Bearer ${notionToken}`;
    debugLog("初始授权头设置:", authHeader.substring(0, 20) + "...");

    // 第1步：获取网易云听歌数据
    document.getElementById("status").textContent = "正在获取网易云数据...";
    const apiUrl = `${API_BASE_URL}/user/record?uid=${neteaseUID}&type=0`;
    debugLog("请求网易云API:", apiUrl);

    const musicDataResponse = await fetch(apiUrl);

    if (!musicDataResponse.ok) {
      throw new Error(`获取网易云数据失败: ${musicDataResponse.status}`);
    }

    const musicData = await musicDataResponse.json();
    debugLog("获取到的网易云数据:", musicData);

    if (!musicData.allData || musicData.code !== 200) {
      throw new Error(`获取数据出错: ${musicData.message || "未知错误"}`);
    }

    // 第2步：处理数据为CSV格式
    document.getElementById("status").textContent = "正在处理数据...";
    const processedData = processNeteaseData(musicData.allData);
    debugLog(`处理完成，共 ${processedData.length} 条记录`);

    // 添加下载按钮，允许用户下载数据
    addDownloadButton(processedData);

    // 第3步：上传到Notion
    document.getElementById("status").textContent = "正在上传到Notion...";
    debugLog("准备上传到Notion，数据示例:", processedData.slice(0, 2));
    debugLog("使用的令牌:", notionToken.substring(0, 10) + "...");

    try {
      // 先尝试获取用户信息，测试令牌是否有效
      debugLog("测试Notion令牌有效性...");
      document.getElementById("status").textContent = "正在验证Notion授权...";

      // 确保授权头格式正确，使用标准Bearer格式
      // 注意：此处不需要再处理令牌，因为processNotionToken已经添加了Bearer前缀
      const userResponse = await fetch(`${NOTION_API_URL}/users/me`, {
        method: "GET",
        headers: {
          Authorization: notionToken,
          "Notion-Version": "2022-06-28",
          "Content-Type": "application/json",
        },
      });

      if (!userResponse.ok) {
        const errorText = await userResponse.text();
        debugLog("Notion令牌无效:", errorText);

        // 如果授权失败，提示用户共享页面并重新授权
        if (userResponse.status === 401) {
          debugLog("授权验证失败，401错误");

          // 显示诊断信息
          const helpText = document.createElement("div");
          helpText.style.marginTop = "10px";
          helpText.style.padding = "10px";
          helpText.style.backgroundColor = "#fff3cd";
          helpText.style.borderRadius = "4px";
          helpText.style.border = "1px solid #ffeeba";
          helpText.innerHTML = `
            <p><strong>Notion API访问问题</strong></p>
            <p>可能原因:</p>
            <ol>
              <li>Notion集成权限可能需要调整</li>
              <li>您可能需要在Notion中手动共享页面给集成</li>
              <li>您的令牌可能需要刷新</li>
            </ol>
            <p>点击"授权Notion"按钮重新获取授权</p>
          `;
          document.body.appendChild(helpText);

          // 显示错误信息但不清除token
          document.getElementById(
            "status"
          ).textContent = `❌ Notion API返回401错误，请尝试重新授权`;

          // 显示页面共享提示
          showSharePageTips();

          throw new Error(
            `Notion授权验证失败: ${userResponse.status} - API token is invalid.`
          );
        } else {
          // 尝试解析错误信息
          let errorDetail = "";
          try {
            const errorObj = JSON.parse(errorText);
            errorDetail = errorObj.message || "";
          } catch (e) {
            errorDetail = errorText.substring(0, 100);
          }

          // 显示更详细的错误信息
          const errorMessage = `Notion授权验证失败: ${userResponse.status}${
            errorDetail ? " - " + errorDetail : ""
          }`;
          document.getElementById("status").textContent = `❌ ${errorMessage}`;

          // 显示解决方案提示
          const helpText = document.createElement("div");
          helpText.style.marginTop = "10px";
          helpText.style.padding = "10px";
          helpText.style.backgroundColor = "#fff3cd";
          helpText.style.borderRadius = "4px";
          helpText.style.border = "1px solid #ffeeba";
          helpText.innerHTML = `
            <p><strong>可能的解决方案:</strong></p>
            <ol>
              <li>请尝试重新授权Notion</li>
              <li>确保Notion集成已正确配置</li>
              <li>检查您的网络连接</li>
              <li>下载数据备份以免丢失</li>
            </ol>
          `;
          document.body.appendChild(helpText);

          throw new Error(errorMessage);
        }
      }

      const userData = await userResponse.json();
      debugLog("Notion用户信息:", userData);

      // 获取用户可访问的页面列表
      debugLog("获取用户页面列表...");
      document.getElementById("status").textContent =
        "正在获取Notion页面列表...";

      // 使用统一的授权头格式
      const searchResponse = await fetch(`${NOTION_API_URL}/search`, {
        method: "POST",
        headers: {
          Authorization: notionToken,
          "Content-Type": "application/json",
          "Notion-Version": "2022-06-28",
        },
        body: JSON.stringify({
          filter: {
            value: "page",
            property: "object",
          },
          sort: {
            direction: "descending",
            timestamp: "last_edited_time",
          },
        }),
      });

      if (!searchResponse.ok) {
        const errorText = await searchResponse.text();
        debugLog("获取页面列表失败:", errorText);

        // 如果是没有访问权限的错误(401或403)，提示用户共享页面
        if (searchResponse.status === 401 || searchResponse.status === 403) {
          document.getElementById(
            "status"
          ).textContent = `❌ 获取Notion页面列表失败: 没有足够权限`;

          // 显示页面共享提示
          showSharePageTips();

          throw new Error("未找到可用的Notion页面，请确保您已将页面共享给集成");
        }

        throw new Error(`获取Notion页面列表失败: ${searchResponse.status}`);
      }

      const searchResults = await searchResponse.json();
      debugLog("找到页面数量:", searchResults.results.length);

      if (searchResults.results.length === 0) {
        // 提示用户共享页面
        document.getElementById(
          "status"
        ).textContent = `❌ 未找到可用的Notion页面`;

        // 显示页面共享提示
        showSharePageTips();

        throw new Error("未找到可用的Notion页面，请确保您已将页面共享给集成");
      }

      // 使用第一个页面作为父页面
      const parentPageId = searchResults.results[0].id;
      debugLog("使用页面作为父页面:", parentPageId);

      // 创建数据库
      document.getElementById("status").textContent = "正在创建Notion数据库...";

      // 使用统一的授权头格式
      const createDatabaseResponse = await fetch(
        `${NOTION_API_URL}/databases`,
        {
          method: "POST",
          headers: {
            Authorization: notionToken,
            "Content-Type": "application/json",
            "Notion-Version": "2022-06-28",
          },
          body: JSON.stringify({
            parent: {
              type: "page_id",
              page_id: parentPageId,
            },
            title: [
              {
                type: "text",
                text: {
                  content: `网易云听歌记录 - ${neteaseUID}`,
                },
              },
            ],
            properties: {
              歌曲名: {
                title: {},
              },
              歌手: {
                rich_text: {},
              },
              专辑: {
                rich_text: {},
              },
              播放次数: {
                number: {},
              },
              评分: {
                number: {},
              },
              发布日期: {
                date: {},
              },
              时长: {
                rich_text: {},
              },
              VIP歌曲: {
                rich_text: {},
              },
              已购买: {
                rich_text: {},
              },
              封面: {
                url: {},
              },
              MV链接: {
                url: {},
              },
              "累计听歌时间(分钟)": {
                number: {},
              },
            },
          }),
        }
      );

      if (!createDatabaseResponse.ok) {
        const errorText = await createDatabaseResponse.text();
        debugLog("创建数据库失败:", errorText);
        throw new Error(
          `创建Notion数据库失败: ${createDatabaseResponse.status}`
        );
      }

      const dbResult = await createDatabaseResponse.json();
      const databaseId = dbResult.id;
      debugLog("创建的数据库ID:", databaseId);
      debugLog("数据库URL:", dbResult.url);

      // 第二步：上传数据到数据库
      document.getElementById(
        "status"
      ).textContent = `正在上传数据到Notion数据库...`;

      // 由于Notion API限制，我们需要分批次上传数据
      const batchSize = 5; // 减小批次大小以降低失败率
      let successCount = 0;

      // 使用统一的授权格式，不再需要特别设置authHeader
      debugLog(
        "上传数据时使用的授权令牌:",
        notionToken.substring(0, 20) + "..."
      );

      for (let i = 0; i < processedData.length; i += batchSize) {
        const batch = processedData.slice(i, i + batchSize);
        document.getElementById(
          "status"
        ).textContent = `正在上传数据... (${i}/${processedData.length})`;
        debugLog(
          `处理批次 ${Math.floor(i / batchSize) + 1}/${Math.ceil(
            processedData.length / batchSize
          )}`
        );

        const promises = batch.map((item) => {
          return fetch(`${NOTION_API_URL}/pages`, {
            method: "POST",
            headers: {
              Authorization: notionToken,
              "Content-Type": "application/json",
              "Notion-Version": "2022-06-28",
            },
            body: JSON.stringify({
              parent: {
                database_id: databaseId,
              },
              properties: {
                歌曲名: {
                  title: [
                    {
                      text: { content: item.name },
                    },
                  ],
                },
                歌手: {
                  rich_text: [
                    {
                      text: { content: item.artist },
                    },
                  ],
                },
                专辑: {
                  rich_text: [
                    {
                      text: { content: item.album },
                    },
                  ],
                },
                播放次数: {
                  number: item.playCount,
                },
                评分: {
                  number: item.score,
                },
                发布日期: {
                  date: {
                    start:
                      item.publishTime !== "未知日期" ? item.publishTime : null,
                  },
                },
                时长: {
                  rich_text: [
                    {
                      text: { content: item.duration },
                    },
                  ],
                },
                VIP歌曲: {
                  rich_text: [
                    {
                      text: { content: item.isVip },
                    },
                  ],
                },
                已购买: {
                  rich_text: [
                    {
                      text: { content: item.isPurchased },
                    },
                  ],
                },
                封面: {
                  url: item.cover,
                },
                MV链接: {
                  url: item.mv || null,
                },
                "累计听歌时间(分钟)": {
                  number: item.totalTimeMin,
                },
              },
            }),
          }).then((response) => {
            if (!response.ok) {
              return response.text().then((text) => {
                debugLog(`添加记录失败: ${response.status}`, text);
                return Promise.reject(
                  new Error(`添加记录失败: ${response.status}`)
                );
              });
            }
            return response.json();
          });
        });

        try {
          const results = await Promise.allSettled(promises);
          const successful = results.filter((r) => r.status === "fulfilled");
          successCount += successful.length;

          debugLog(
            `批次 ${Math.floor(i / batchSize) + 1} 结果: 成功 ${
              successful.length
            }/${batch.length}`
          );

          // 如果有失败的请求，添加短暂延迟避免API限制
          if (successful.length < batch.length) {
            debugLog("检测到部分请求失败，添加延迟...");
            await new Promise((resolve) => setTimeout(resolve, 2000));
          }
        } catch (batchError) {
          debugLog("处理批次时出错:", batchError);
          // 继续处理下一批次，不中断整个过程
        }
      }

      document.getElementById(
        "status"
      ).textContent = `✅ 已成功同步 ${successCount} 条记录至Notion！数据库URL: ${dbResult.url}`;

      // 创建一个链接，方便用户访问数据库
      const linkContainer = document.createElement("div");
      linkContainer.style.marginTop = "10px";
      linkContainer.innerHTML = `<a href="${dbResult.url}" target="_blank">点击查看Notion数据库</a>`;
      document.body.appendChild(linkContainer);
    } catch (notionError) {
      debugLog("Notion API调用失败:", notionError);

      // 打印当前使用的token信息
      debugLog(
        "当前使用的token:",
        notionToken ? notionToken.substring(0, 10) + "..." : "未设置"
      );

      document.getElementById(
        "status"
      ).textContent = `❌ Notion操作失败: ${notionError.message}`;

      // 自动显示手动上传指南
      const errorMessage = document.createElement("div");
      errorMessage.style.marginTop = "10px";
      errorMessage.style.color = "#721c24";
      errorMessage.style.backgroundColor = "#f8d7da";
      errorMessage.style.padding = "10px";
      errorMessage.style.borderRadius = "4px";
      errorMessage.style.marginBottom = "10px";
      errorMessage.innerHTML = `
        <p><strong>数据上传到Notion失败</strong></p>
        <p>错误信息: ${notionError.message}</p>
        <p>不用担心，您的数据已安全获取，可以通过手动方式上传。</p>
      `;
      document.body.appendChild(errorMessage);

      // 显示手动上传指南
      addManualUploadSection();
    }
  } catch (error) {
    document.getElementById(
      "status"
    ).textContent = `❌ 发生错误：${error.message}`;
    debugLog("同步过程中出错:", error);
  } finally {
    document.getElementById("sync-data").disabled = false;
  }
});

// 处理网易云数据
function processNeteaseData(allData) {
  return allData.map((item) => {
    const song = item.song;

    // 处理歌手名（合并多个歌手）
    const artists = song.ar.map((ar) => ar.name);
    const artistNames = artists.join(" / ");

    // 处理时长（ms转分钟:秒）
    const durationMs = song.dt;
    const minutes = Math.floor(durationMs / 60000);
    const seconds = Math.floor((durationMs % 60000) / 1000);
    const duration = `${minutes}:${seconds.toString().padStart(2, "0")}`;

    // 处理发布时间
    let publishTime = "未知日期";
    if (song.publishTime) {
      try {
        const date = new Date(song.publishTime);
        publishTime = date.toISOString().split("T")[0];
      } catch (e) {
        debugLog("日期转换错误:", e);
      }
    }

    // 计算累计听歌时间(分钟)
    const totalTimeMin =
      Math.round(((item.playCount * song.dt) / 1000 / 60) * 100) / 100;

    return {
      name: song.name,
      artist: artistNames,
      album: song.al.name,
      cover: song.al.picUrl,
      playCount: item.playCount,
      score: item.score,
      publishTime: publishTime,
      duration: duration,
      isVip: song.fee > 0 ? "是" : "否",
      isPurchased: song.privilege?.payed > 0 ? "是" : "否",
      mv: song.mv ? `https://music.163.com/mv?id=${song.mv}` : "",
      totalTimeMin: totalTimeMin,
    };
  });
}

// 调试功能：手动启用同步按钮
document.getElementById("debug-btn").addEventListener("click", function () {
  // 检查当前状态
  debugLog("调试按钮点击 - 当前状态:");
  debugLog(
    "- Notion令牌:",
    notionToken ? "已设置" : "未设置",
    notionToken ? notionToken.substring(0, 10) + "..." : ""
  );
  debugLog("- 网易云UID:", neteaseUID || "未设置");

  // 如果UID未设置，从输入框获取
  if (!neteaseUID) {
    neteaseUID = document.getElementById("netease-uid").value.trim();
    if (neteaseUID) {
      debugLog("从输入框获取UID:", neteaseUID);
      chrome.storage.local.set({ neteaseUID: neteaseUID });
    }
  }

  // 如果令牌未设置，尝试从存储重新加载
  if (!notionToken) {
    chrome.storage.local.get(["notionToken"], function (result) {
      if (result.notionToken) {
        notionToken = result.notionToken;
        debugLog("从存储重新加载令牌:", notionToken.substring(0, 10) + "...");
      }

      // 强制启用同步按钮
      document.getElementById("sync-data").disabled = false;
      document.getElementById("status").textContent =
        "调试模式：已强制启用同步按钮";
    });
  } else {
    // 强制启用同步按钮
    document.getElementById("sync-data").disabled = false;
    document.getElementById("status").textContent =
      "调试模式：已强制启用同步按钮";
  }
});

// 添加下载按钮功能
function addDownloadButton(data) {
  // 移除可能已存在的下载按钮
  const existingBtn = document.getElementById("download-data-btn");
  if (existingBtn) {
    existingBtn.remove();
  }

  // 创建下载按钮
  const downloadBtn = document.createElement("button");
  downloadBtn.id = "download-data-btn";
  downloadBtn.textContent = "💾 下载数据 (CSV)";
  downloadBtn.style.marginTop = "10px";
  downloadBtn.style.backgroundColor = "#4CAF50";
  downloadBtn.style.color = "white";
  downloadBtn.style.border = "none";
  downloadBtn.style.padding = "8px";
  downloadBtn.style.borderRadius = "4px";
  downloadBtn.style.cursor = "pointer";

  // 添加点击事件
  downloadBtn.addEventListener("click", () => {
    // 转换为CSV格式
    const csvContent = convertToCSV(data);

    // 创建Blob对象
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });

    // 创建下载链接
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);

    // 生成文件名
    const fileName = `netease_songs_${neteaseUID}_${
      new Date().toISOString().split("T")[0]
    }.csv`;

    // 设置下载属性
    link.setAttribute("href", url);
    link.setAttribute("download", fileName);
    link.style.display = "none";

    // 添加到DOM并触发点击
    document.body.appendChild(link);
    link.click();

    // 清理
    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }, 100);

    // 显示文件列表区域
    showFilesSection(fileName, data.length);
  });

  // 添加到DOM
  const statusElem = document.getElementById("status");
  statusElem.parentNode.insertBefore(downloadBtn, statusElem.nextSibling);
}

// 显示文件列表区域
function showFilesSection(fileName, recordCount) {
  const filesSection = document.getElementById("files-section");
  filesSection.style.display = "block";

  const filesList = document.getElementById("files-list");

  // 创建文件项
  const fileItem = document.createElement("div");
  fileItem.style.marginBottom = "8px";
  fileItem.style.padding = "8px";
  fileItem.style.backgroundColor = "#eee";
  fileItem.style.borderRadius = "4px";

  const currentTime = new Date().toLocaleTimeString();
  fileItem.innerHTML = `
    <div><strong>${fileName}</strong></div>
    <div>共 ${recordCount} 条记录</div>
    <div style="font-size: 12px; color: #666;">下载时间: ${currentTime}</div>
  `;

  // 替换或添加到列表
  if (filesList.textContent === "暂无数据文件") {
    filesList.innerHTML = "";
  }

  filesList.insertBefore(fileItem, filesList.firstChild);
}

// 将数据转换为CSV格式
function convertToCSV(data) {
  if (!data || !data.length) return "";

  // 获取表头
  const headers = Object.keys(data[0]);

  // 创建CSV内容
  let csvContent = "\uFEFF"; // 添加UTF-8 BOM以支持中文

  // 添加表头
  csvContent += headers.join(",") + "\r\n";

  // 添加数据行
  data.forEach((item) => {
    const row = headers.map((header) => {
      // 处理字段中的逗号和引号
      let field =
        item[header] !== null && item[header] !== undefined
          ? item[header].toString()
          : "";
      if (field.includes(",") || field.includes('"') || field.includes("\n")) {
        field = '"' + field.replace(/"/g, '""') + '"';
      }
      return field;
    });
    csvContent += row.join(",") + "\r\n";
  });

  return csvContent;
}

// 添加手动上传CSV到Notion功能
function addManualUploadSection() {
  // 检查是否已存在
  if (document.getElementById("manual-upload-section")) {
    return;
  }

  // 创建手动上传区域
  const uploadSection = document.createElement("div");
  uploadSection.id = "manual-upload-section";
  uploadSection.style.marginTop = "20px";
  uploadSection.style.padding = "10px";
  uploadSection.style.border = "1px solid #ddd";
  uploadSection.style.borderRadius = "5px";
  uploadSection.style.backgroundColor = "#f5f5f5";

  uploadSection.innerHTML = `
    <h4>手动上传CSV到Notion</h4>
    <p style="font-size: 13px; color: #666;">如果自动上传失败，您可以使用此方法手动上传</p>
    
    <div class="manual-step">
      <div class="manual-step-title">步骤 1: 下载您的网易云数据文件</div>
      <div class="step-content">
        <p>确保您已经点击了上方的"💾 下载数据 (CSV)"按钮，将数据保存到本地</p>
      </div>
    </div>
    
    <div class="manual-step">
      <div class="manual-step-title">步骤 2: 打开您的Notion，创建一个新的数据库</div>
      <div class="step-content">
        <ol style="margin-top: 5px; padding-left: 20px;">
          <li>在Notion中点击"+ 新页面"</li>
          <li>选择"表格 - 数据库"</li>
          <li>将默认的"Name"列重命名为"歌曲名"</li>
          <li>点击右上角"+"按钮，添加以下属性：
            <ul style="margin-top: 3px;">
              <li>歌手（文本）</li>
              <li>专辑（文本）</li>
              <li>播放次数（数字）</li>
              <li>评分（数字）</li>
              <li>发布日期（日期）</li>
              <li>时长（文本）</li>
              <li>VIP歌曲（文本）</li>
              <li>已购买（文本）</li>
              <li>封面（URL）</li>
              <li>MV链接（URL）</li>
              <li>累计听歌时间(分钟)（数字）</li>
            </ul>
          </li>
        </ol>
      </div>
    </div>
    
    <div class="manual-step">
      <div class="manual-step-title">步骤 3: 在Notion数据库中导入CSV</div>
      <div class="step-content">
        <ol style="margin-top: 5px; padding-left: 20px;">
          <li>点击右上角"..."菜单</li>
          <li>选择"合并与导出" > "导入"</li>
          <li>选择"CSV"，然后上传您下载的文件</li>
          <li>在映射字段步骤中，确保所有字段正确映射</li>
          <li>点击"确认并导入"</li>
          <li>导入完成后，检查数据是否正确显示</li>
        </ol>
      </div>
    </div>
    
    <div class="manual-step">
      <div class="manual-step-title">步骤 4: 调整视图和排序</div>
      <div class="step-content">
        <p>导入完成后，您可以：</p>
        <ul style="margin-top: 3px; padding-left: 20px;">
          <li>按"播放次数"排序，查看最常听的歌曲</li>
          <li>添加筛选器，例如只显示VIP歌曲</li>
          <li>创建新视图，如"画廊视图"以展示专辑封面</li>
          <li>创建图表，分析您的听歌习惯</li>
        </ul>
      </div>
    </div>
    
    <div style="margin-top: 15px; text-align: center;">
      <button id="open-notion-btn" class="notion-btn">
        <span style="margin-right: 5px;">打开 Notion</span>
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M5 3L11 9L5 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button>
    </div>
  `;

  // 添加到页面
  document.body.appendChild(uploadSection);

  // 添加打开Notion按钮事件
  document.getElementById("open-notion-btn").addEventListener("click", () => {
    window.open("https://www.notion.so/", "_blank");
  });
}

// 修改错误处理，添加手动上传选项
document.addEventListener("DOMContentLoaded", function () {
  // 添加手动上传按钮
  const debugBtn = document.getElementById("debug-btn");
  const manualUploadBtn = document.createElement("button");
  manualUploadBtn.id = "manual-upload-btn";
  manualUploadBtn.textContent = "📝 显示手动上传指南";
  manualUploadBtn.className = "manual-upload-btn";

  manualUploadBtn.addEventListener("click", function () {
    addManualUploadSection();
  });

  // 添加到DOM
  debugBtn.parentNode.insertBefore(manualUploadBtn, debugBtn.nextSibling);
});

// 全局错误处理
window.addEventListener("error", function (event) {
  debugLog("全局错误:", event.message, "at", event.filename, ":", event.lineno);
  // 尝试恢复授权问题
  if (event.message && event.message.includes("authHeader")) {
    debugLog("检测到授权相关错误，尝试恢复...");
    try {
      if (typeof notionToken !== "undefined") {
        // 确保令牌格式正确
        if (!notionToken.startsWith("Bearer ")) {
          window.recoveryAuthHeader = `Bearer ${notionToken}`;
        } else {
          window.recoveryAuthHeader = notionToken;
        }
        debugLog(
          "已创建恢复授权头:",
          window.recoveryAuthHeader.substring(0, 20) + "..."
        );
      }
    } catch (e) {
      debugLog("恢复授权头失败:", e);
    }
  }
});

// 将页面共享给集成的提示函数
function showSharePageTips() {
  // 如果已经显示了提示，不再重复显示
  if (document.getElementById("share-page-tips")) {
    return;
  }

  const tipsContainer = document.createElement("div");
  tipsContainer.id = "share-page-tips";
  tipsContainer.style.marginTop = "15px";
  tipsContainer.style.padding = "10px";
  tipsContainer.style.backgroundColor = "#e3f2fd";
  tipsContainer.style.borderRadius = "4px";
  tipsContainer.style.border = "1px solid #bbdefb";

  tipsContainer.innerHTML = `
    <h4 style="margin-top: 0;">如何共享Notion页面给集成</h4>
    <ol style="padding-left: 20px; margin-bottom: 10px;">
      <li>在Notion中打开您想要共享的页面</li>
      <li>点击右上角的"分享"按钮</li>
      <li>在分享菜单中，选择"邀请"选项卡</li>
      <li>搜索并选择您的集成名称（通常以Netease开头）</li>
      <li>确认共享</li>
    </ol>
    <p>完成上述步骤后，您的集成将有权限访问该页面及其中的内容。</p>
    <button id="open-notion-btn" style="background-color: #2196f3; color: white; border: none; padding: 8px 12px; border-radius: 4px; cursor: pointer;">打开Notion</button>
  `;

  document.body.appendChild(tipsContainer);

  // 添加打开Notion按钮点击事件
  document.getElementById("open-notion-btn").addEventListener("click", () => {
    window.open("https://www.notion.so/", "_blank");
  });
}

// 添加下载CSV按钮的事件监听器
document
  .getElementById("download-csv-btn")
  .addEventListener("click", async function () {
    try {
      // 获取输入框中的网易云UID
      const inputUID = document.getElementById("netease-uid").value.trim();
      if (inputUID) {
        neteaseUID = inputUID;
        chrome.storage.local.set({ neteaseUID: neteaseUID });
      }

      if (!neteaseUID) {
        document.getElementById("status").textContent = "请先输入网易云音乐UID";
        return;
      }

      document.getElementById("status").textContent = "正在获取数据，请稍候...";

      // 获取网易云数据
      const apiUrl = `${API_BASE_URL}/user/record?uid=${neteaseUID}&type=0`;
      debugLog("请求网易云API:", apiUrl);

      const musicDataResponse = await fetch(apiUrl);

      if (!musicDataResponse.ok) {
        throw new Error(`获取网易云数据失败: ${musicDataResponse.status}`);
      }

      const musicData = await musicDataResponse.json();
      debugLog("获取到的网易云数据:", musicData);

      if (!musicData.allData || musicData.code !== 200) {
        throw new Error(`获取数据出错: ${musicData.message || "未知错误"}`);
      }

      // 处理数据
      document.getElementById("status").textContent = "正在处理数据...";
      const processedData = processNeteaseData(musicData.allData);
      debugLog(`处理完成，共 ${processedData.length} 条记录`);

      // 转换为CSV
      const csvContent = convertToCSV(processedData);

      // 创建Blob对象
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });

      // 创建下载链接
      const link = document.createElement("a");
      const url = URL.createObjectURL(blob);

      // 生成文件名
      const fileName = `netease_songs_${neteaseUID}_${
        new Date().toISOString().split("T")[0]
      }.csv`;

      // 设置下载属性
      link.setAttribute("href", url);
      link.setAttribute("download", fileName);
      link.style.display = "none";

      // 添加到DOM并触发点击
      document.body.appendChild(link);
      link.click();

      // 清理
      setTimeout(() => {
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }, 100);

      document.getElementById(
        "status"
      ).textContent = `✅ CSV下载成功！共${processedData.length}条记录`;

      // 显示文件列表区域
      showFilesSection(fileName, processedData.length);
    } catch (error) {
      document.getElementById(
        "status"
      ).textContent = `❌ 发生错误：${error.message}`;
      debugLog("下载CSV过程中出错:", error);
    }
  });
